#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
RESULT="`which tree`"
R=$?
if [ $R == 0 ] && [[ $PATH = *"${HOME}/tree/bin"* ]] && [ -f "${HOME}/tree/bin/tree" ]; then
  A="`tree ${DIR} | tail -n 3`"
  B="`cat ${DIR}/trickytree.sh`" # ensure script is not modified
  echo "${A}${B}" | md5sum
else
  echo "tree not found in PATH or installed in wrong location"
fi
