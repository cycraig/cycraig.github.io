#include <cstdio>
#include <omp.h>
using namespace std;

int a(int n);

int main(void) {
	fprintf( stdout, "Starting...");
	fflush(stdout);
	fprintf( stdout, "%d\n",a(20));
	return 0;
}

int a(int n) {
	int s = 0;
	#pragma omp parallel for reduction(+:s) firstprivate(n) num_threads(2)
	for(int i = 2; i <= n; i++) {
	    if(omp_get_num_threads() < 2) {
	        s += 1;
	    }
		bool p = true;
		for(int j = 2; j < i && p; j++) {
			if(i % j == 0) {
				p = false;
			}
		}
		if(p) {
			s += i;
		}
	}
	int s2 = 0;
	for(int i = 2; i <= n; i++) {
		bool p = true;
		for(int j = 2; j < i && p; j++) {
			if(i % j == 0) {
				p = false;
			}
		}
		if(p) {
		    if(i < 10) fprintf(stderr, "%d\n", i);
		    else fprintf(stderr, "%d\n", i);
			s2 += i;
		}
	}
	return (s - s*(1-(s==s2)));
}
